#PCA - EXAMPLE 1
#CENSUS TRACT DATA

census.tract = read.table(file.choose(),header=TRUE)

# Make summary and plots of data:
 
summary(census.tract)
plot(census.tract)

# Compute means and covariance matrix
 
apply(census.tract,2,mean)
S=cov(census.tract)

# Compute eigenvalues/eigenvectors and the proportion of total variation explained
 
eigen.census=eigen(S)
eigen.census$values
eigen.census$vectors
cumsum(eigen.census$values)/sum(eigen.census$values)

# Use commands for principal components
 
census.pcomp=prcomp(census.tract)
summary(census.pcomp)
print(census.pcomp)
plot(census.pcomp)

screeplot(census.pcomp, npcs=4, type="lines")
biplot(census.pcomp)