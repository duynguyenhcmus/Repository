#PCA - EXAMPLE
#SWISS BANK NOTES DATA

dat <- read.table(file.choose())
names(dat)

#MEAN VECTOR

Xbar <- apply(dat,2,mean); Xbar

# SAMPLE COVARIANCE MATRIX S

S <- round(cov(dat),4); S

# EIGENVALUES OF S

eigen.val <- round(eigen(S)$values,4); eigen.val 

# Proportion of variance

var.prop <- round(eigen.val/sum(eigen.val),4); var.prop

# Cummulative proportion

cum.prop <- round(cumsum(eigen.val)/sum(eigen.val),4); cum.prop

# Summary table
PCs <- 1:6
tab1 <- cbind(PCs,eigen.val,var.prop,cum.prop)
tab1

# EIGENVECTORS OF S

eigen.vec <- round(eigen(S)$vectors,4); eigen.vec
colnames(eigen.vec) <- c('Y1','Y2','Y3','Y4','Y5','Y6')
rownames(eigen.vec) <- c('X1 (Length)','X2 (Left)','X3 (Right)','X4 (Bottom)',
'X5 (Top)', 'X6 (Diagonal)')
eigen.vec

# CORRELATION BETWEEN MEASURES AND PCs
r <- matrix(0,6,6)

{for(i in 1:6)
   for(k in 1:6)
          r[i,k] <- round(eigen.vec[k,i]*sqrt(eigen.val[i]/S[k,k]),4)
}
r <- t(r)
colnames(r) <- c('Y1','Y2','Y3','Y4','Y5','Y6')
rownames(r) <- c('X1 (Length)','X2 (Left)','X3 (Right)','X4 (Bottom)',
'X5 (Top)', 'X6 (Diagonal)')

r

#SOME INFERENCES:
# Y1: a constrast between Bottom and Top
# Y2: overall size, except for Diagonal
# Y3 & Y4: nothing obvious
# Y5: something like "image"
# Y6: measurement error

#RUN PCA

# USE COVARIANCE MATRIX
pca1 <- princomp(dat)

# USE CORRELATION MATRIX
pca2 <- princomp(dat, cor=TRUE)
print(pca1)
summary(pca1)

#DETECT OUTLIERS
plot(pca1$scores[,5:6],pch=20,col='red')

