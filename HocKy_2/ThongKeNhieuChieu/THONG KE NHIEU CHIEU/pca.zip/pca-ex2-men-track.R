#PCA - EXAMPLE 2
#MEN TRACK DATA

data = read.csv(file.choose(),header=TRUE)
men.track = data[2:9]
# Make summary and plots of data:
 
summary(men.track)
plot(men.track)

# Compute means and covariance matrix
 
tab = cbind(apply(men.track,2,mean), apply(men.track,2,sd))
colnames(tab) = c("Mean", "STD")
tab
S=round(cov(men.track),3); S 


# Compute eigenvalues/eigenvectors and the proportion of total variation explained
 
eigen.mentrack=eigen(S)
eigen.mentrack$values
eigen.mentrack$vectors
cumsum(eigen.mentrack$values)/sum(eigen.mentrack$values)

# Use commands for principal components
 
mentrack.pcomp=prcomp(men.track)
summary(mentrack.pcomp)
print(mentrack.pcomp)
plot(mentrack.pcomp)

# LOADINGS
loadings(princomp(men.track))

# PREDICT VALUES
predict(mentrack.pcomp)[,1:2]

screeplot(mentrack.pcomp, npcs=4, type="lines")
biplot(mentrack.pcomp)