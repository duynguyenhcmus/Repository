#  Exercise 8.6 
 
# a)
# Read the sample mean vector and sample covariance matrix into R and compute eigenvalues and eigenvectors
 
xbar=matrix(c(155.60,14.70),2,1)
S=matrix(c(7476.45,303.62,303.62,26.19),2,2)
eigenS=eigen(S)
eigenS$values
eigenS$vectors
 
# c)
# Sketch the constant density ellipse (corresponding to 50%)
 
library(ellipse)
plot(ellipse(S,centre=xbar,level=0.50),type='l',xlim=c(20,270),ylim=c(0,30))
points(xbar[1,],xbar[2,])
 
# Draw the axes of the ellipse:
 
c=sqrt(1.4)
axis1=c*sqrt(eigenS$val[1])*eigenS$vec[,1]
axis2=c*sqrt(eigenS$val[2])*eigenS$vec[,2]
lines(c(xbar[1,]-axis1[1],xbar[1,]+axis1[1]),c(xbar[2,]-axis1[2],xbar[2,]+axis1[2]),lty=1)
lines(c(xbar[1,]-axis2[1], xbar[1,]+axis2[1]),c(xbar[2,]-axis2[2],xbar[2,]+axis2[2]),lty=1)
 
# In order to make the plot of the ellipse look "normal", you have to make sure that the scale is the same on both axes (which may be difficult for the present situation)
 
# Draw the first principal component:
 
b=eigenS$vec[2,1]/eigenS$vec[1,1]
a=xbar[2,]-b*xbar[1,]
abline(a,b,lty=2)
 
# Draw the second principal component:
 
b=eigenS$vec[2,2]/eigenS$vec[1,2]
a=xbar[2,]-b*xbar[1,]
abline(a,b,lty=2)